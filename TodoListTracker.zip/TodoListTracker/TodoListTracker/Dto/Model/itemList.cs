﻿using System.ComponentModel.DataAnnotations;

namespace TodoListTracker.Dto.Model
{
    public class itemList
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string? Task { get; set; }
        [Required]
        public string? Description { get; set; }
        [Required]
        public string? DueDate { get; set; }
        [Required]
        public string? Priority { get; set; }
        [Required]
        public string? TaskStatus { get; set; }
        [Required]
        public string? DateAssign { get; set; }
        [Required]
        public string? AssignedTo { get; set; }
    }
}
