﻿using Microsoft.AspNetCore.Identity;

namespace TodoListTracker.Dto.Model
{
    public class ApplicationUser : IdentityUser
    {
    }
}
