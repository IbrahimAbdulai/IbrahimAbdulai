﻿using System.ComponentModel.DataAnnotations;

namespace TodoListTracker.Dto.Model
{
    public record struct itemListDto
    (
        int id,
        string Task,
         string Description,
         string DueDate,
         string Priority,
         string TaskStatus,
         string DateAssign,
         string AssignedTo
    );
}
