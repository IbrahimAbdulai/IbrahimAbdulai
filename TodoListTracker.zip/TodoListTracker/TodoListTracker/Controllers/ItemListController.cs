﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TodoListTracker.Dto;
using TodoListTracker.Dto.Model;

namespace TodoListTracker.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemListController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public ItemListController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllList()
        {
            var itemLists = await _context.itemLists.ToListAsync();
            return Ok(itemLists);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSingleStudent(int id)
        {
            var itemList = await _context.itemLists.FindAsync(id);
            if (itemList is null)
                return BadRequest("item Not Found");
            return Ok(itemList);
        }

        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<itemList>> AddHotel(itemListDto itemDto)
        {

            var newCharacter = new itemList
            {
                ID = itemDto.id,
                Task = itemDto.Task,
                Description = itemDto.Description,
                DueDate = itemDto.DueDate,
                Priority = itemDto.Priority,
                TaskStatus = itemDto.TaskStatus,
                DateAssign = itemDto.DateAssign,
                AssignedTo = itemDto.AssignedTo
            };
            _context.itemLists.Add(newCharacter);
            await _context.SaveChangesAsync();
            return Ok(new Response { Data = "record added successfully", Status = "Success", Message = "item added Successfully" });

        }
        [HttpPut]
        [Route("Update")]
        public async Task<IActionResult> UpdateList([FromBody] itemList stu)
        {
            var existingList = await _context.itemLists.FindAsync(stu.ID);
            if (existingList is null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "Item  not found." });

            existingList.Task = stu.Task;
            existingList.Description = stu.Description;
            existingList.DueDate = stu.DueDate;
            existingList.Priority = stu.Priority;
            existingList.TaskStatus = stu.TaskStatus;
            existingList.DateAssign = stu.DateAssign;
            existingList.AssignedTo = stu.AssignedTo;
           

            await _context.SaveChangesAsync();
            return Ok(new Response { Data = existingList.ToString(), Status = "Success", Message = "item Updated Successfully" });

        }
        [HttpDelete]
        [Route("Delete")]
        public async Task<IActionResult> DeleteItem(int id)
        {
            var itemList = await _context.itemLists.FindAsync(id);
            if (itemList is null)
                return BadRequest("item Not Found");

            _context.itemLists.Remove(itemList);
            await _context.SaveChangesAsync();
            return Ok(new Response { Data = GetAllList().ToString(), Status = "Success", Message = "Item List Updated Successfully" });

        }


    }
   
}
